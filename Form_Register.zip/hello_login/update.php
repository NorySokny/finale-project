<?php 

    require_once("connection.php");

    if(isset($_POST['update']))
    {
        $id = $_GET['id'];
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $age = $_POST['age'];

        $query = " update users set fname = '".$fname."', lname='".$lname."',age='".$age."' where id='".$id."'";
        $result = mysqli_query($con,$query);

        if($result)
        {
            header("location:view.php");
        }
        else
        {
            echo ' Please Check Your Query ';
        }
    }
    else
    {
        header("location:view.php");
    }


?>