<?php

    require_once("connection.php");

    if(isset($_POST['btn_save']))
    {
        if(empty($_POST['fname']) || empty($_POST['lname']) || empty($_POST['age']))
        {
            echo ' Please Fill in the Blanks ';
        }
        else
        {
            $fname = $_POST['fname'];
            $lname = $_POST['lname'];
            $age = $_POST['age'];

            $query = " INSERT INTO `users`(`id`,`fname`, `lname`, `age`) values(null,'$fname','$lname','$age')";
            $result = mysqli_query($con,$query);

            if($result)
            {
                header("location:view.php");
            }
            else
            {
                echo '  Please Check Your Query ';
            }
        }
    }
    else
    {
        header("location:view.php");
    }



?>