<?php 
@$con = new mysqli("localhost","root","","test_db");
if(!$con) { die(" Connection Error "); }else echo "ok"; 
?>